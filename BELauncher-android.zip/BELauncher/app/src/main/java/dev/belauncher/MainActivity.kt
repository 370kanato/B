package dev.belauncher

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = ModStore(this)
        setContent { App(store) }
    }
}

private val Green = Color(0xFF52A535)

@Composable
fun App(store: ModStore) {
    val ctx = LocalContext.current
    var mods by remember { mutableStateOf(store.list()) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { store.import(ctx, uri); mods = store.list() }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Green)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF1E1E1F)) {
            Column(Modifier.statusBarsPadding()) {
                Box(
                    Modifier.fillMaxWidth().height(200.dp).background(
                        Brush.verticalGradient(listOf(Color(0xFF6FA8DC), Color(0xFF5B9A38), Color(0xFF6B4A2B)))
                    ), contentAlignment = Alignment.Center
                ) {
                    Text("MINECRAFT\nBEDROCK EDITION", color = Color.White, fontSize = 26.sp,
                        fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                }
                Row(Modifier.fillMaxWidth().background(Color(0xFF111112)).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Text(Loader.status(ctx, store) + "", Modifier.weight(1f), fontSize = 12.sp, color = Color(0xFFA8A8AB))
                    Button(onClick = { Loader.launch(ctx as Activity, store) },
                        enabled = Mc.info(ctx) != null, shape = RoundedCornerShape(0.dp),
                        contentPadding = PaddingValues(horizontal = 36.dp, vertical = 14.dp)) {
                        Text("PLAY", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Mods", Modifier.weight(1f), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    OutlinedButton(onClick = { pick.launch(arrayOf("*/*")) }, shape = RoundedCornerShape(0.dp)) { Text("+ .so を追加") }
                }
                LazyColumn(Modifier.padding(horizontal = 16.dp)) {
                    items(mods) { m ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Color(0xFF2B2B2C)).padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text(m.name, Modifier.weight(1f))
                            Switch(checked = m.enabled, onCheckedChange = { store.setEnabled(m.name, it); mods = store.list() })
                        }
                    }
                }
            }
        }
    }
}
