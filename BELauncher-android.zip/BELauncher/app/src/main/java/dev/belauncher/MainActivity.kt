package dev.belauncher

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Random
import kotlin.math.abs

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = ModStore(this)
        setContent { App(store) }
    }
}

private val Bg = Color(0xFF1E1E1F)
private val Bar = Color(0xFF111112)
private val Panel = Color(0xFF2B2B2C)
private val Green = Color(0xFF52A535)
private val Sub = Color(0xFFA8A8AB)
private val Shd = TextStyle(shadow = Shadow(Color(0xAA000000), Offset(4f, 4f), 0f))

@Composable
fun App(store: ModStore) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var mods by remember { mutableStateOf(store.list()) }
    var report by remember { mutableStateOf("") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { report = if (store.import(ctx, uri)) "追加しました" else ".so ファイルを選んでください"; mods = store.list() }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Green)) {
        Surface(Modifier.fillMaxSize(), color = Bg, contentColor = Color.White) {
            Column(Modifier.statusBarsPadding().navigationBarsPadding()) {
                TopTabs(tab) { tab = it }
                when (tab) {
                    0 -> PlayTab(ctx, store)
                    1 -> ModsTab(mods, report, { pick.launch(arrayOf("*/*")) }, { report = Loader.testLoad(ctx, store) }) { n, on -> store.setEnabled(n, on); mods = store.list() }
                    else -> InstallTab(ctx, store, report) { report = Loader.diagnose(ctx) }
                }
            }
        }
    }
}

@Composable
fun TopTabs(sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Bar)) {
        listOf("PLAY", "MODS", "INSTALL").forEachIndexed { i, t ->
            Column(Modifier.weight(1f).clickable { onSel(i) }.padding(top = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally) {
                Text(t, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp,
                    color = if (i == sel) Color.White else Sub)
                Spacer(Modifier.height(10.dp))
                Box(Modifier.height(3.dp).fillMaxWidth(0.5f).background(if (i == sel) Green else Color.Transparent))
            }
        }
    }
}

@Composable
fun PixelScene(modifier: Modifier) {
    Canvas(modifier) {
        val cell = 14.dp.toPx()
        val cols = (size.width / cell).toInt() + 1
        val rows = (size.height / cell).toInt() + 1
        val g = (rows * 0.55f).toInt()
        val rnd = Random(7)
        val clouds = setOf(2 to 2, 3 to 2, 4 to 2, 3 to 3, 10 to 4, 11 to 4, 12 to 4, 11 to 5, 18 to 1, 19 to 1, 20 to 1)
        for (r in 0 until rows) for (c in 0 until cols) {
            val n = rnd.nextFloat() * 0.14f - 0.07f
            val base = when {
                r < g -> if ((c to r) in clouds) Color(0xFFF4FAFF) else lerp(Color(0xFF7FB8EA), Color(0xFFBBDDF8), r.toFloat() / g)
                r == g -> Color(0xFF5B9A38)
                r < g + 3 -> Color(0xFF7A5230)
                else -> Color(0xFF7D7D7D)
            }
            val col = if (r < g) base else lerp(base, if (n > 0) Color.White else Color.Black, abs(n) * 2.2f)
            drawRect(col, Offset(c * cell, r * cell), Size(cell + 1, cell + 1))
        }
    }
}

@Composable
fun PlayButton(enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth(0.85f).height(64.dp).alpha(if (enabled) 1f else 0.5f)
            .clickable(enabled = enabled, onClick = onClick)
            .drawBehind {
                drawRect(Color(0xFF3C8527))
                drawRect(Color(0x66FFFFFF), size = Size(size.width, 3.dp.toPx()))
                drawRect(Color(0x55000000), Offset(0f, size.height - 6.dp.toPx()), Size(size.width, 6.dp.toPx()))
                drawRect(Color(0xFF1F4A14), style = Stroke(3.dp.toPx()))
            },
        contentAlignment = Alignment.Center
    ) {
        Text("PLAY", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 5.sp,
            color = Color.White, style = Shd)
    }
}

@Composable
fun PlayTab(ctx: android.content.Context, store: ModStore) {
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            PixelScene(Modifier.matchParentSize())
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("MINECRAFT", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace, color = Color.White, style = Shd)
                Text("BEDROCK EDITION", fontSize = 15.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp,
                    fontFamily = FontFamily.Monospace, color = Color.White, style = Shd)
            }
        }
        Column(Modifier.fillMaxWidth().background(Bar).padding(vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            PlayButton(Mc.info(ctx) != null) { Loader.launch(ctx as Activity, store) }
            Spacer(Modifier.height(10.dp))
            Text(Loader.status(ctx, store), fontSize = 12.sp, color = Sub)
        }
    }
}

@Composable
fun ReportBox(text: String) {
    SelectionContainer {
        Text(text, Modifier.fillMaxWidth().padding(vertical = 10.dp).background(Color(0xFF0C0C0D)).padding(10.dp)
            .heightIn(max = 260.dp).verticalScroll(rememberScrollState()),
            fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = Color(0xFF9FE08A))
    }
}

@Composable
fun ModsTab(mods: List<Mod>, report: String, onAdd: () -> Unit, onTest: () -> Unit, onToggle: (String, Boolean) -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Mods", Modifier.weight(1f), fontSize = 20.sp, fontWeight = FontWeight.Bold)
            OutlinedButton(onClick = onAdd, shape = RoundedCornerShape(0.dp)) { Text("+ .so を追加") }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onTest, shape = RoundedCornerShape(0.dp)) { Text("テスト読み込み(有効なModをロード)") }
        if (report.isNotEmpty()) ReportBox(report)
        if (mods.isEmpty()) Text("Mod がありません。右上のボタンから .so を追加してください。", color = Sub, fontSize = 13.sp)
        LazyColumn {
            items(mods) { m ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp).background(Panel).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(40.dp).background(Color(0xFF3C8527)), contentAlignment = Alignment.Center) {
                        Text(m.name.take(1).uppercase(), fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(m.name, Modifier.weight(1f))
                    Switch(checked = m.enabled, onCheckedChange = { onToggle(m.name, it) })
                }
            }
        }
    }
}

@Composable
fun InstallTab(ctx: android.content.Context, store: ModStore, report: String, onDiag: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Installations", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().background(Panel).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).background(Color(0xFF3C8527)), contentAlignment = Alignment.Center) {
                Text("B", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Bedrock Edition", fontWeight = FontWeight.Bold)
                Text(Loader.status(ctx, store), fontSize = 12.sp, color = Sub)
            }
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onDiag, shape = RoundedCornerShape(0.dp)) { Text("診断を実行") }
        if (report.isNotEmpty()) ReportBox(report)
    }
}
