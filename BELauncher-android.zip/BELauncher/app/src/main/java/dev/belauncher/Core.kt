package dev.belauncher

import android.app.Activity
import android.content.Context
import android.net.Uri
import java.io.File

object Mc {
    const val PKG = "com.mojang.minecraftpe"
    fun info(c: Context) = runCatching { c.packageManager.getPackageInfo(PKG, 0) }.getOrNull()
}

data class Mod(val name: String, val enabled: Boolean)

/** Mod(.so)の保存・有効化管理。Android 14+ は動的ロードするファイルが読み取り専用必須。 */
class ModStore(c: Context) {
    private val dir = File(c.filesDir, "mods").apply { mkdirs() }
    private val prefs = c.getSharedPreferences("mods", Context.MODE_PRIVATE)

    fun list() = dir.listFiles { f -> f.extension == "so" }.orEmpty().sortedBy { it.name }
        .map { Mod(it.name, prefs.getBoolean(it.name, false)) }

    fun setEnabled(name: String, on: Boolean) = prefs.edit().putBoolean(name, on).apply()
    fun enabledFiles() = list().filter { it.enabled }.map { File(dir, it.name) }

    fun import(c: Context, uri: Uri) {
        val name = uri.lastPathSegment?.substringAfterLast('/')?.takeIf { it.endsWith(".so") } ?: return
        val out = File(dir, name).also { if (it.exists()) { it.setWritable(true); it.delete() } }
        c.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { i.copyTo(it) } }
        out.setReadOnly()
    }
}

object Loader {
    fun status(c: Context, s: ModStore): String {
        val i = Mc.info(c) ?: return "Bedrock 未インストール"
        return "Bedrock ${i.versionName} / ${android.os.Build.SUPPORTED_ABIS[0]} / 有効Mod ${s.enabledFiles().size}"
    }

    fun launch(a: Activity, s: ModStore) {
        val mods = s.enabledFiles()
        // TODO(stage 2): インプロセス・ホスト方式
        //  1. a.createPackageContext(Mc.PKG, CONTEXT_INCLUDE_CODE or CONTEXT_IGNORE_SECURITY) でゲームのClassLoaderを取得
        //  2. ゲームの MainActivity をこのプロセス内で起動(ホストActivityが委譲)
        //  3. libminecraftpe.so より前に mods を System.load -> JNI_OnLoad でフック(Dobby/ShadowHook等)
        a.packageManager.getLaunchIntentForPackage(Mc.PKG)?.let(a::startActivity)
    }
}
