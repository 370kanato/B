package dev.belauncher

import android.app.Activity
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.util.zip.ZipFile

object Mc {
    const val PKG = "com.mojang.minecraftpe"
    fun info(c: Context) = runCatching { c.packageManager.getPackageInfo(PKG, 0) }.getOrNull()
}

data class Mod(val name: String, val enabled: Boolean)

/** Mod(.so)の保存・有効化管理。Android 14+ は動的ロードするファイルが読み取り専用必須。 */
class ModStore(c: Context) {
    private val dir = File(c.filesDir, "mods").apply { mkdirs() }
    private val prefs = c.getSharedPreferences("mods", Context.MODE_PRIVATE)

    fun list() = dir.listFiles { f -> f.extension == "so" }.orEmpty().sortedBy { it.name }
        .map { Mod(it.name, prefs.getBoolean(it.name, false)) }

    fun setEnabled(name: String, on: Boolean) = prefs.edit().putBoolean(name, on).apply()
    fun enabledFiles() = list().filter { it.enabled }.map { File(dir, it.name) }

    fun import(c: Context, uri: Uri): Boolean {
        val raw = c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null }
            ?: uri.lastPathSegment?.substringAfterLast('/')
        val name = raw?.let { File(it).name } ?: return false
        if (!name.endsWith(".so")) return false
        val out = File(dir, name).also { if (it.exists()) { it.setWritable(true); it.delete() } }
        c.contentResolver.openInputStream(uri)?.use { i -> out.outputStream().use { i.copyTo(it) } } ?: return false
        out.setReadOnly()
        return true
    }
}

object Loader {
    fun status(c: Context, s: ModStore): String {
        val i = Mc.info(c) ?: return "Bedrock 未インストール"
        return "Bedrock ${i.versionName} / ${android.os.Build.SUPPORTED_ABIS[0]} / 有効Mod ${s.enabledFiles().size}"
    }

    fun launch(a: Activity, s: ModStore) {
        // TODO(stage 2): インプロセス・ホスト方式(診断結果を見て設計する)
        a.packageManager.getLaunchIntentForPackage(Mc.PKG)?.let(a::startActivity)
    }

    /** 有効なModをランチャー自身のプロセスに読み込み、Mod側のログを返す(ゲーム統合前の動作確認)。 */
    fun testLoad(c: Context, s: ModStore): String {
        val mods = s.enabledFiles()
        if (mods.isEmpty()) return "有効なModがありません。スイッチをONにしてください。"
        val log = File(c.filesDir, "mod.log")
        android.system.Os.setenv("BE_LOG_FILE", log.path, true)
        val sb = StringBuilder()
        for (f in mods) {
            val r = try { System.load(f.absolutePath); "load OK" }
            catch (t: Throwable) { "FAILED ${t.javaClass.simpleName}: ${t.message}" }
            sb.appendLine("${f.name}: $r")
        }
        sb.appendLine("--- mod.log ---")
        sb.append(if (log.exists()) log.readText() else "(ログなし)")
        return sb.toString()
    }

    /** ゲーム側の構造を調べる。stage 2 の設計材料。 */
    @Suppress("DEPRECATION")
    fun diagnose(c: Context): String {
        val pi = Mc.info(c) ?: return "Bedrock 未インストール"
        val ai = pi.applicationInfo ?: return "applicationInfo なし"
        val sb = StringBuilder()
        fun l(s: String) { sb.appendLine(s) }
        l("version=${pi.versionName} code=${pi.versionCode}")
        l("deviceAbi=${android.os.Build.SUPPORTED_ABIS.joinToString()}")
        l("base=${ai.sourceDir}")
        l("splits=${ai.splitSourceDirs?.joinToString { File(it).name } ?: "なし"}")
        val nd = File(ai.nativeLibraryDir)
        l("nativeLibDir=${nd.path}")
        l("  files=${nd.list()?.joinToString() ?: "(なし/読めない)"}")
        val apks = listOf(ai.sourceDir) + (ai.splitSourceDirs?.toList() ?: emptyList())
        for (p in apks) {
            val libs = runCatching {
                ZipFile(p).use { z -> z.entries().asSequence().map { it.name }
                    .filter { it.startsWith("lib/") && it.endsWith(".so") }.toList() }
            }.getOrElse { listOf("ERR ${it.message}") }
            l("${File(p).name} libs: ${libs.joinToString().take(300)}")
        }
        runCatching {
            val gc = c.createPackageContext(Mc.PKG, Context.CONTEXT_INCLUDE_CODE or Context.CONTEXT_IGNORE_SECURITY)
            Class.forName("com.mojang.minecraftpe.MainActivity", false, gc.classLoader)
            l("MainActivity class: OK")
        }.onFailure { l("MainActivity class: NG ${it.javaClass.simpleName} ${it.message}") }
        return sb.toString()
    }
}
