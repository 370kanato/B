#include <android/log.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

/* dlopen された瞬間に実行される。ランチャーが渡す BE_LOG_FILE にログを書く。 */
__attribute__((constructor)) static void on_load(void) {
    __android_log_print(ANDROID_LOG_INFO, "BEMod", "testmod loaded pid=%d", (int)getpid());
    const char *p = getenv("BE_LOG_FILE");
    if (!p) return;
    FILE *f = fopen(p, "a");
    if (!f) return;
    fprintf(f, "[testmod] loaded pid=%d time=%ld\n", (int)getpid(), (long)time(NULL));
    fclose(f);
}
